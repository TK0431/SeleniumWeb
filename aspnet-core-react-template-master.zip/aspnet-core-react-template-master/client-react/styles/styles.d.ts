declare module "*.styl" {
    let styles: any;
    export default styles;
}

declare module "*.css" {
    let styles: any;
    export default styles;
}
