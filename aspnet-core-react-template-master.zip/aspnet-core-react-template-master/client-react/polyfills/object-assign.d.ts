declare interface ObjectConstructor {
    assign(...objects: Object[]): Object;
}
