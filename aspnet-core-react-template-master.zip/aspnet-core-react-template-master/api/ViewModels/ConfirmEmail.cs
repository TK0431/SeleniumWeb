namespace aspnetCoreReactTemplate.ViewModels
{
    public class ConfirmEmail
    {
        public string user_id { get; set; }
        public string token { get; set; }
    }
}
