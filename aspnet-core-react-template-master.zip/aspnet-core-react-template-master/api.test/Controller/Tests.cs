﻿using System.Collections.Generic;
using System.Linq;
using app = aspnetCoreReactTemplate;

namespace Tests.Controller
{
    public class Tests
    {
        // [Fact]
        // public void Index_ReturnsAViewResult_WithAListOfBrainstormSessions()
        // {
        //     var controller = new app.Controllers.ContactsController(null);
        //     var result = (IEnumerable<app.Models.Contact>)controller.Get();

        //     Assert.NotEqual(result.Count(), 0);
        // }
    }
}
